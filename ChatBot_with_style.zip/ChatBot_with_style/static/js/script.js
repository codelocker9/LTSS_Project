const responses = {
    "hello": "Hi there!",
    "how are you?": "I'm doing well, thank you for asking!",
    "who created you?": "I was developed a team of learners in Leseding Technical Secondary School as a trusty partner to the user(you😊), to help them in any way they need. Cool right?😉",
    "default": "I'm still under development, but I'm learning new things every day!"
};
  
function sendMessage() {
    const message = (document.getElementById("message").value).trim();
    const response = getResponse(message.toLowerCase());
    document.getElementById("response").innerText = 'Bud: ' +  response;
    document.getElementById("message").value = ""; // Clear input field
    addBubble(message, true);
    setTimeout(function() {
        addBubble(response, false);
    }, 1000);
}
  
function getResponse(message) {
    return responses[message] || responses["default"];
}

function addBubble(message, User) {
    var Chat = document.getElementById("Chat");
    var BubbleClass = User ? "user-bubble": "bubble";
    var bubble = document.createElement("div");
    bubble.className = 'card-body';
    bubble.innerHTML = 'You: ' + message;
    // bubble.id = 'response';
    Chat.appendChild(bubble);
    Chat.scrollTop = Chat.scrollHeight;
}